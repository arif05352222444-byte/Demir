# LED TV Banner — APK Nasıl Alınır (Kolay Yol)

Bilgisayara hiçbir program kurmana gerek yok. GitHub sitesi senin yerine APK'yı üretecek.
Aşağıdaki adımları sırayla yap.

---

## ADIM 1 — GitHub hesabı aç (ücretsiz)
1. Tarayıcıda **github.com** adresine gir.
2. **Sign up** (Kaydol) de, e-posta ve şifre ile ücretsiz hesap aç.
   (Zaten hesabın varsa bu adımı geç.)

---

## ADIM 2 — Yeni bir depo (repository) oluştur
1. Sağ üstte **+** işaretine bas → **New repository**.
2. Repository name kısmına bir isim yaz, örn: **led-tv-banner**
3. **Public** seçili kalsın.
4. **Create repository** butonuna bas.

---

## ADIM 3 — Proje dosyalarını yükle
1. Sana verdiğim **LedTvBanner.zip** dosyasını bilgisayarda **sağ tık → Çıkart / Extract** ile aç.
   İçinden bir **LedTvBanner** klasörü çıkacak.
2. Yeni açtığın boş depoda **"uploading an existing file"** yazısına tıkla
   (ya da **Add file → Upload files**).
3. LedTvBanner klasörünün **İÇİNDEKİ HER ŞEYİ** (app klasörü, .github klasörü,
   build.gradle, settings.gradle, gradle.properties vb.) sürükleyip bırak.
   ÖNEMLİ: Klasörün kendisini değil, **içindekileri** yükle.
4. Aşağıda **Commit changes** (yeşil buton) bas.

> Not: `.github` klasörü gizli görünebilir ama mutlaka yüklenmeli. Zip'te o klasör var.

---

## ADIM 4 — APK otomatik üretilsin
1. Dosyalar yüklenince üstteki **Actions** sekmesine tıkla.
2. "APK Olustur" adında bir işlem kendiliğinden başlamış olacak.
   (Sarı nokta = çalışıyor, yeşil tik = bitti, kırmızı = hata)
3. İlk sefer 3–6 dakika sürebilir. Yeşil tik gelene kadar bekle.

Eğer kendiliğinden başlamadıysa: Actions → solda **APK Olustur** → sağda **Run workflow** → **Run workflow**.

---

## ADIM 5 — APK'yı indir
1. Yeşil tik gelince o işleme tıkla.
2. Sayfanın en altında **Artifacts** bölümünde **LED-TV-Banner-APK** yazacak.
3. Üstüne tıkla, bir **.zip** inecek. Onu aç, içinden **app-debug.apk** çıkacak.

İşte senin APK'n bu: **app-debug.apk**

---

## ADIM 6 — APK'yı Android TV / TV Box'a kur
1. APK'yı bir **USB belleğe** kopyala, USB'yi TV'ye tak.
   (Veya telefonla "Send Files to TV" gibi bir uygulamayla gönder.)
2. TV'de bir **dosya yöneticisi** uygulamasıyla app-debug.apk'ya tıkla.
3. "Bilinmeyen kaynaklara izin ver" çıkarsa **İzin ver** de.
4. **Kur (Install)** de. Bitince uygulama TV menüsünde görünür.

---

## KULLANIM (kumanda ile)
- Uygulamayı aç → **Yeni Banner Oluştur**
- Yazıyı gir, renk / hız / boyut / efekt / çerçeve / arka planı seç (her satırda OK'a basınca değişir)
- **Tam Ekran Başlat** de.

Tam ekranda kumanda:
- **OK** = durdur / devam
- **Geri** = ayar ekranına dön
- **Sağ / Sol** = hızı artır / azalt
- **Yukarı / Aşağı** = yazı boyutunu büyüt / küçült

---

## Bir sorun olursa
Actions'ta **kırmızı** (hata) çıkarsa, o işleme tıkla, kırmızı satıra tıkla, çıkan
yazıyı bana kopyala. Hemen düzeltirim ve dosyayı güncellerim.
