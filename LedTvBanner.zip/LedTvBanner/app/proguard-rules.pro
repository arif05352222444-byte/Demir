# Keep WebView JS interface if used in future
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
