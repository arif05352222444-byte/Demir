package com.arif.ledtvbanner.media

object YoutubeIdParser {

    /**
     * Extracts the 11-char video id from common YouTube URL formats:
     *  - https://www.youtube.com/watch?v=VIDEO_ID
     *  - https://youtu.be/VIDEO_ID
     *  - https://www.youtube.com/shorts/VIDEO_ID
     *  - https://m.youtube.com/watch?v=VIDEO_ID
     * Returns null if nothing valid is found.
     */
    fun parse(url: String?): String? {
        if (url.isNullOrBlank()) return null
        val u = url.trim()
        val patterns = listOf(
            Regex("[?&]v=([A-Za-z0-9_-]{11})"),
            Regex("youtu\\.be/([A-Za-z0-9_-]{11})"),
            Regex("shorts/([A-Za-z0-9_-]{11})"),
            Regex("embed/([A-Za-z0-9_-]{11})")
        )
        for (p in patterns) {
            val m = p.find(u)
            if (m != null) return m.groupValues[1]
        }
        // Maybe the user just pasted a bare id.
        if (Regex("^[A-Za-z0-9_-]{11}$").matches(u)) return u
        return null
    }
}
