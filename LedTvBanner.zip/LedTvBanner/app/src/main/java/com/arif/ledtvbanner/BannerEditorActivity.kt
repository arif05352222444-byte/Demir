package com.arif.ledtvbanner

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.arif.ledtvbanner.banner.LedBannerView
import com.arif.ledtvbanner.data.Background
import com.arif.ledtvbanner.data.BannerConfig
import com.arif.ledtvbanner.data.BannerStore
import com.arif.ledtvbanner.data.FrameEffect
import com.arif.ledtvbanner.data.LedEffect
import com.arif.ledtvbanner.data.ScrollDirection
import com.arif.ledtvbanner.data.ScrollSpeed
import com.arif.ledtvbanner.data.TextColor
import com.arif.ledtvbanner.data.TextSize
import com.arif.ledtvbanner.util.Constants
import org.json.JSONObject

/**
 * Create / edit a banner. Each setting is a focusable button: press OK to cycle
 * to the next value. A live LED preview is shown on top.
 */
class BannerEditorActivity : AppCompatActivity() {

    private lateinit var preview: LedBannerView
    private lateinit var config: BannerConfig
    private var editIndex: Int = -1

    private lateinit var etName: EditText
    private lateinit var etText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editor)

        // Load existing config if we came from the saved list.
        val json = intent.getStringExtra(Constants.EXTRA_BANNER_JSON)
        editIndex = intent.getIntExtra(Constants.EXTRA_EDIT_INDEX, -1)
        config = if (json != null) {
            try { BannerConfig.fromJson(JSONObject(json)) } catch (e: Exception) { BannerConfig() }
        } else BannerConfig()

        preview = findViewById(R.id.preview)
        preview.config = config.copyOf()

        etName = findViewById(R.id.etName)
        etText = findViewById(R.id.etText)
        etName.setText(config.name)
        etText.setText(config.text)

        etText.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) refreshPreview()
        }
        etName.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) config.name = etName.text.toString().ifBlank { "Banner" }
        }

        setupCycler(R.id.btnColor, "Yazı rengi") {
            config.textColor = next(TextColor.values(), config.textColor)
            config.textColor.label
        }
        setupCycler(R.id.btnSize, "Yazı boyutu") {
            config.size = next(TextSize.values(), config.size)
            config.size.label
        }
        setupCycler(R.id.btnBold, "Kalınlık") {
            config.bold = !config.bold
            if (config.bold) "Kalın" else "Normal"
        }
        setupCycler(R.id.btnSpeed, "Kayma hızı") {
            config.speed = next(ScrollSpeed.values(), config.speed)
            config.speed.label
        }
        setupCycler(R.id.btnDirection, "Kayma yönü") {
            config.direction = next(ScrollDirection.values(), config.direction)
            config.direction.label
        }
        setupCycler(R.id.btnLedEffect, "LED efekti") {
            config.ledEffect = next(LedEffect.values(), config.ledEffect)
            config.ledEffect.label
        }
        setupCycler(R.id.btnFrame, "Çerçeve") {
            config.frameEffect = next(FrameEffect.values(), config.frameEffect)
            config.frameEffect.label
        }
        setupCycler(R.id.btnBackground, "Arka plan") {
            config.background = next(Background.values(), config.background)
            config.background.label
        }

        findViewById<Button>(R.id.btnPreview).setOnClickListener { refreshPreview() }
        findViewById<Button>(R.id.btnSave).setOnClickListener { save(false) }
        findViewById<Button>(R.id.btnStart).setOnClickListener { save(true) }

        // Initialise button labels.
        updateLabel(R.id.btnColor, "Yazı rengi", config.textColor.label)
        updateLabel(R.id.btnSize, "Yazı boyutu", config.size.label)
        updateLabel(R.id.btnBold, "Kalınlık", if (config.bold) "Kalın" else "Normal")
        updateLabel(R.id.btnSpeed, "Kayma hızı", config.speed.label)
        updateLabel(R.id.btnDirection, "Kayma yönü", config.direction.label)
        updateLabel(R.id.btnLedEffect, "LED efekti", config.ledEffect.label)
        updateLabel(R.id.btnFrame, "Çerçeve", config.frameEffect.label)
        updateLabel(R.id.btnBackground, "Arka plan", config.background.label)
    }

    private fun <T> next(values: Array<T>, current: T): T {
        val i = values.indexOf(current)
        return values[(i + 1) % values.size]
    }

    private fun setupCycler(id: Int, label: String, onCycle: () -> String) {
        val b = findViewById<Button>(id)
        b.setOnClickListener {
            val value = onCycle()
            updateLabel(id, label, value)
            refreshPreview()
        }
    }

    private fun updateLabel(id: Int, label: String, value: String) {
        findViewById<Button>(id).text = "$label:  $value"
    }

    private fun refreshPreview() {
        config.text = etText.text.toString()
        config.name = etName.text.toString().ifBlank { "Banner" }
        preview.config = config.copyOf()
    }

    private fun save(thenStart: Boolean) {
        refreshPreview()
        if (config.text.isBlank()) {
            Toast.makeText(this, "Lütfen bir yazı girin.", Toast.LENGTH_SHORT).show()
            return
        }
        BannerStore(this).save(config)
        Toast.makeText(this, "Kaydedildi: ${config.name}", Toast.LENGTH_SHORT).show()
        if (thenStart) {
            val i = android.content.Intent(this, FullScreenBannerActivity::class.java)
            i.putExtra(Constants.EXTRA_BANNER_JSON, config.toJson().toString())
            startActivity(i)
        }
    }
}
