package com.arif.ledtvbanner.media

import android.annotation.SuppressLint
import android.webkit.WebView
import android.webkit.WebViewClient

/**
 * Loads a YouTube video as a background using the IFrame player inside a WebView.
 * The LED banner is drawn on top, so this video shows behind it (visible fon),
 * exactly as requested.
 */
object YoutubeWebViewManager {

    @SuppressLint("SetJavaScriptEnabled")
    fun load(webView: WebView, videoId: String, onError: () -> Unit) {
        try {
            webView.settings.javaScriptEnabled = true
            webView.settings.mediaPlaybackRequiresUserGesture = false
            webView.settings.domStorageEnabled = true
            webView.setBackgroundColor(android.graphics.Color.BLACK)
            webView.webViewClient = object : WebViewClient() {
                override fun onReceivedError(
                    view: WebView?, request: android.webkit.WebResourceRequest?,
                    error: android.webkit.WebResourceError?
                ) {
                    onError()
                }
            }
            val html = buildHtml(videoId)
            webView.loadDataWithBaseURL(
                "https://www.youtube.com", html, "text/html", "utf-8", null
            )
        } catch (e: Exception) {
            onError()
        }
    }

    private fun buildHtml(videoId: String): String {
        // Autoplay, muted off (sound on), loop, no controls, fills the screen.
        return """
            <!DOCTYPE html>
            <html>
            <head>
              <meta name="viewport" content="width=device-width, initial-scale=1">
              <style>
                html,body{margin:0;padding:0;background:#000;height:100%;overflow:hidden;}
                #player{position:fixed;top:0;left:0;width:100%;height:100%;}
                iframe{width:100%;height:100%;border:0;}
              </style>
            </head>
            <body>
              <div id="player"></div>
              <script src="https://www.youtube.com/iframe_api"></script>
              <script>
                var player;
                function onYouTubeIframeAPIReady(){
                  player = new YT.Player('player', {
                    videoId: '$videoId',
                    playerVars: {
                      autoplay:1, controls:0, loop:1, playlist:'$videoId',
                      modestbranding:1, rel:0, fs:0, disablekb:1, playsinline:1
                    },
                    events: {
                      'onReady': function(e){ e.target.playVideo(); }
                    }
                  });
                }
              </script>
            </body>
            </html>
        """.trimIndent()
    }

    fun destroy(webView: WebView?) {
        try {
            webView?.loadUrl("about:blank")
            webView?.stopLoading()
            webView?.onPause()
            webView?.removeAllViews()
            webView?.destroy()
        } catch (_: Exception) {}
    }
}
