package com.arif.ledtvbanner

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.arif.ledtvbanner.data.YoutubeStore
import com.arif.ledtvbanner.media.YoutubeIdParser
import com.arif.ledtvbanner.util.Constants
import java.net.URLEncoder

/**
 * In-app YouTube search using a WebView (no API key needed).
 * The user searches, taps a video in the YouTube results, and the video id is
 * captured from the URL change. They confirm and it becomes the banner background.
 */
class YoutubeSearchActivity : AppCompatActivity() {

    private lateinit var store: YoutubeStore
    private lateinit var webView: WebView
    private lateinit var etSearch: EditText
    private var lastPromptedId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_youtube_search)
        store = YoutubeStore(this)

        etSearch = findViewById(R.id.etSearch)
        webView = findViewById(R.id.webView)
        etSearch.setText(store.lastSearchQuery)

        setupWebView()

        findViewById<Button>(R.id.btnSearch).setOnClickListener {
            doSearch(etSearch.text.toString())
        }
        findViewById<Button>(R.id.btnManual).setOnClickListener {
            // Return without a video; user will paste a link in Music settings.
            finish()
        }

        renderRecent()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.isFocusable = true
        webView.isFocusableInTouchMode = true
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?, request: WebResourceRequest?
            ): Boolean {
                checkForVideo(request?.url?.toString(), view)
                return false
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                super.doUpdateVisitedHistory(view, url, isReload)
                checkForVideo(url, view)
            }

            override fun onReceivedError(
                view: WebView?, request: WebResourceRequest?, error: WebResourceError?
            ) {
                if (request?.isForMainFrame == true) showError()
            }
        }
    }

    private fun doSearch(query: String) {
        val q = query.trim()
        if (q.isEmpty()) {
            Toast.makeText(this, "Arama metni girin.", Toast.LENGTH_SHORT).show()
            return
        }
        store.addRecentSearch(q)
        store.lastSearchQuery = q
        renderRecent()
        lastPromptedId = null
        try {
            val enc = URLEncoder.encode(q, "UTF-8")
            webView.loadUrl("https://www.youtube.com/results?search_query=$enc")
        } catch (e: Exception) {
            showError()
        }
    }

    private fun checkForVideo(url: String?, view: WebView?) {
        val id = YoutubeIdParser.parse(url) ?: return
        if (id == lastPromptedId) return
        lastPromptedId = id
        val rawTitle = view?.title ?: ""
        val title = rawTitle.replace(" - YouTube", "").trim().ifEmpty { id }
        promptUse(id, title)
    }

    private fun promptUse(id: String, title: String) {
        AlertDialog.Builder(this)
            .setTitle("Video seçildi")
            .setMessage("\"$title\"\n\nBu video banner fonu olarak seçilsin mi?")
            .setPositiveButton("Evet, kullan") { _, _ -> selectVideo(id, title) }
            .setNeutralButton("Önizle") { d, _ -> d.dismiss() }   // keep playing in WebView
            .setNegativeButton("Geri dön") { d, _ -> d.dismiss() }
            .show()
    }

    private fun selectVideo(id: String, title: String) {
        store.addRecentVideo(id, title)
        val data = Intent()
        data.putExtra(Constants.EXTRA_YT_VIDEO_ID, id)
        data.putExtra(Constants.EXTRA_YT_VIDEO_TITLE, title)
        setResult(RESULT_OK, data)
        finish()
    }

    private fun renderRecent() {
        val searchRow = findViewById<LinearLayout>(R.id.recentSearchRow)
        searchRow.removeAllViews()
        for (q in store.getRecentSearches()) {
            searchRow.addView(chip(q) { etSearch.setText(q); doSearch(q) })
        }
        val videoRow = findViewById<LinearLayout>(R.id.recentVideoRow)
        videoRow.removeAllViews()
        for (v in store.getRecentVideos()) {
            videoRow.addView(chip(v.title.take(22)) { selectVideo(v.id, v.title) })
        }
    }

    private fun chip(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 14f
        b.setTextColor(0xFFEDEDED.toInt())
        b.background = getDrawable(R.drawable.btn_menu_bg)
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(0, 0, 10, 0)
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }

    private fun showError() {
        AlertDialog.Builder(this)
            .setTitle("Bağlantı hatası")
            .setMessage("YouTube araması açılamadı. İnternet bağlantısını kontrol edin.")
            .setPositiveButton("Tekrar dene") { _, _ -> doSearch(store.lastSearchQuery) }
            .setNeutralButton("Manuel link gir") { _, _ -> finish() }
            .setNegativeButton("Kapat") { d, _ -> d.dismiss() }
            .show()
    }

    override fun onDestroy() {
        try {
            webView.stopLoading()
            webView.loadUrl("about:blank")
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView.destroy()
        } catch (_: Exception) {}
        super.onDestroy()
    }
}
