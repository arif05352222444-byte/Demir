package com.arif.ledtvbanner.banner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.Choreographer
import android.view.View
import com.arif.ledtvbanner.data.Background
import com.arif.ledtvbanner.data.BannerConfig
import com.arif.ledtvbanner.data.FrameEffect
import com.arif.ledtvbanner.data.LedEffect
import com.arif.ledtvbanner.data.ScrollDirection
import com.arif.ledtvbanner.data.TextColor

/**
 * Draws the banner text as a grid of glowing LED dots, like a real LED sign.
 *
 * Technique: the text is rendered once into a small "low resolution" bitmap
 * where 1 pixel == 1 LED dot. Each frame we sample that bitmap and draw a
 * glowing circle for every lit pixel. This supports ANY text including Turkish
 * characters (Ç Ğ İ Ö Ş Ü) and scales to 720p / 1080p / 4K automatically.
 */
class LedBannerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var config: BannerConfig = BannerConfig()
        set(value) {
            field = value
            textBitmap = null   // force rebuild
            resetScroll()
            invalidate()
        }

    private var paused = false

    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(20, 20, 20)
        strokeWidth = 1f
    }
    private val textRenderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.LEFT
    }
    private val framePaint = Paint(Paint.ANTI_ALIAS_FLAG)

    // The low-res text bitmap: width = number of dot-columns, height = ledRows.
    private var textBitmap: Bitmap? = null
    private var textCols = 0
    private var ledRows = 0

    private var scrollOffset = 0f          // in dot-columns (or rows for vertical)
    private var lastFrameNanos = 0L
    private var blinkOn = true
    private var blinkTimer = 0f
    private var hue = 0f                    // for color cycling

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var currentGlow = false
    private var currentLitColor = Color.RED

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (lastFrameNanos == 0L) lastFrameNanos = frameTimeNanos
            val dt = (frameTimeNanos - lastFrameNanos) / 1_000_000_000f
            lastFrameNanos = frameTimeNanos
            if (!paused) advance(dt)
            invalidate()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    fun start() {
        lastFrameNanos = 0L
        Choreographer.getInstance().removeFrameCallback(frameCallback)
        Choreographer.getInstance().postFrameCallback(frameCallback)
    }

    fun stop() {
        Choreographer.getInstance().removeFrameCallback(frameCallback)
    }

    fun togglePause() { paused = !paused }
    fun isPaused() = paused

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        start()
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }

    private fun resetScroll() {
        scrollOffset = 0f
        lastFrameNanos = 0L
    }

    private fun advance(dt: Float) {
        // Blink timing
        blinkTimer += dt
        if (blinkTimer >= 0.5f) { blinkTimer = 0f; blinkOn = !blinkOn }
        // Color cycle
        hue = (hue + dt * 60f) % 360f

        val pitch = pitchPx()
        if (pitch <= 0f) return
        val speedDots = config.speed.pixelsPerSecond / pitch
        when (config.direction) {
            ScrollDirection.RIGHT_TO_LEFT,
            ScrollDirection.LEFT_TO_RIGHT,
            ScrollDirection.TOP_TO_BOTTOM,
            ScrollDirection.BOTTOM_TO_TOP -> scrollOffset += speedDots * dt
            ScrollDirection.BLINK_STATIC -> { /* no movement */ }
        }
    }

    /** Pixel size of one LED dot cell, derived from the text band height. */
    private fun pitchPx(): Float {
        val rows = config.size.ledRows
        val usable = height * config.size.bandFraction
        return if (rows > 0) usable / rows else 0f
    }

    private fun buildTextBitmap() {
        ledRows = config.size.ledRows
        textRenderPaint.typeface =
            if (config.bold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
        textRenderPaint.letterSpacing = 0.08f
        val text = if (config.text.isEmpty()) " " else config.text.replace("\n", "  ")

        // Supersample: render the text 3x larger, then shrink to the dot grid.
        // This keeps letter holes (counters) open so words stay readable.
        val scale = 3
        textRenderPaint.textSize = (ledRows * scale).toFloat()
        val fm = textRenderPaint.fontMetrics
        val wHi = Math.max(scale, Math.ceil(textRenderPaint.measureText(text).toDouble()).toInt() + scale * 2)
        val hHi = ledRows * scale
        val hi = Bitmap.createBitmap(wHi, hHi, Bitmap.Config.ARGB_8888)
        val c = Canvas(hi)
        c.drawColor(Color.TRANSPARENT)
        val baseline = (hHi - (fm.ascent + fm.descent)) / 2f
        c.drawText(text, scale.toFloat(), baseline, textRenderPaint)

        val w = Math.max(1, wHi / scale)
        val bmp = Bitmap.createScaledBitmap(hi, w, ledRows, true)
        hi.recycle()
        textBitmap = bmp
        textCols = w
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawBackground(canvas)

        if (height == 0) return
        if (textBitmap == null) buildTextBitmap()
        val bmp = textBitmap ?: return

        val pitch = pitchPx()
        if (pitch <= 0f) return
        val radius = pitch * 0.38f

        val screenCols = (width / pitch).toInt() + 2
        val topMargin = (height - ledRows * pitch) / 2f

        // Effects
        val blinkEffect = config.ledEffect == LedEffect.BLINK ||
                config.direction == ScrollDirection.BLINK_STATIC
        if (blinkEffect && !blinkOn) {
            drawFrame(canvas)
            return
        }
        currentGlow = config.ledEffect == LedEffect.NEON_GLOW || config.ledEffect == LedEffect.BLUR_GLOW
        currentLitColor = currentTextColor()

        val vertical = config.direction == ScrollDirection.TOP_TO_BOTTOM ||
                config.direction == ScrollDirection.BOTTOM_TO_TOP

        // Keep the scrolling text INSIDE the frame border (no overflow over the edge).
        val margin = if (config.frameEffect != FrameEffect.OFF) pitch * 1.6f else 0f
        canvas.save()
        canvas.clipRect(margin, margin, width - margin, height - margin)
        if (vertical) {
            drawVertical(canvas, bmp, pitch, radius)
        } else {
            drawHorizontal(canvas, bmp, pitch, radius, topMargin, screenCols)
        }
        canvas.restore()

        drawFrame(canvas)
    }

    private fun drawHorizontal(
        canvas: Canvas, bmp: Bitmap, pitch: Float, radius: Float,
        topMargin: Float, screenCols: Int
    ) {
        // Static (blinking) mode: just centre the text, no scrolling.
        if (config.direction == ScrollDirection.BLINK_STATIC) {
            val startCol = (screenCols - textCols) / 2
            for (col in 0 until textCols) {
                val sx = startCol + col
                if (sx < 0 || sx >= screenCols) continue
                val cx = sx * pitch + pitch / 2f
                for (row in 0 until ledRows) {
                    if (isLit(bmp, col, row)) {
                        val cy = topMargin + row * pitch + pitch / 2f
                        drawDot(canvas, cx, cy, radius)
                    }
                }
            }
            return
        }

        // Continuous marquee. The text + a small gap form a repeating strip.
        val gap = (screenCols / 2).coerceAtLeast(8)
        val strip = textCols + gap
        if (strip <= 0) return
        val phase = ((scrollOffset % strip) + strip) % strip
        val leftToRight = config.direction == ScrollDirection.LEFT_TO_RIGHT

        for (sx in 0 until screenCols) {
            val raw = if (leftToRight) (sx - phase) else (sx + phase)
            var pos = (Math.floor(raw.toDouble()).toInt()) % strip
            if (pos < 0) pos += strip
            if (pos >= textCols) continue          // we're in the gap
            val cx = sx * pitch + pitch / 2f
            for (row in 0 until ledRows) {
                if (isLit(bmp, pos, row)) {
                    val cy = topMargin + row * pitch + pitch / 2f
                    drawDot(canvas, cx, cy, radius)
                }
            }
        }
    }

    private fun drawVertical(
        canvas: Canvas, bmp: Bitmap, pitch: Float, radius: Float
    ) {
        // The whole horizontal line of text slides up or down.
        val screenRows = (height / pitch).toInt() + 2
        val screenColsTotal = (width / pitch).toInt() + 2
        val startCol = (screenColsTotal - textCols) / 2
        val gap = (screenRows / 2).coerceAtLeast(6)
        val travel = ledRows + screenRows + gap
        if (travel <= 0) return
        val phase = ((scrollOffset % travel) + travel) % travel
        val upward = config.direction == ScrollDirection.BOTTOM_TO_TOP
        val topRow = if (upward) (screenRows - phase) else (phase - ledRows)

        for (row in 0 until ledRows) {
            val sr = Math.round(topRow + row)
            if (sr < 0 || sr >= screenRows) continue
            val cy = sr * pitch + pitch / 2f
            for (col in 0 until textCols) {
                if (isLit(bmp, col, row)) {
                    val sx = startCol + col
                    if (sx < 0 || sx >= screenColsTotal) continue
                    val cx = sx * pitch + pitch / 2f
                    drawDot(canvas, cx, cy, radius)
                }
            }
        }
    }

    /**
     * Draws one LED dot: optional soft (small) glow halo, the coloured body,
     * and a brighter centre so it reads like a real LED. The halo is kept small
     * so neighbouring dots stay separate and the text stays readable.
     */
    private fun drawDot(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        if (currentGlow) {
            glowPaint.color = currentLitColor
            glowPaint.alpha = 30
            canvas.drawCircle(cx, cy, radius * 1.18f, glowPaint)
        }
        dotPaint.color = currentLitColor
        dotPaint.alpha = 255
        canvas.drawCircle(cx, cy, radius, dotPaint)
        // bright centre highlight
        dotPaint.color = blendWhite(currentLitColor, 0.5f)
        canvas.drawCircle(cx, cy, radius * 0.42f, dotPaint)
    }

    private fun blendWhite(c: Int, t: Float): Int {
        val r = (Color.red(c) * (1 - t) + 255 * t).toInt().coerceIn(0, 255)
        val g = (Color.green(c) * (1 - t) + 255 * t).toInt().coerceIn(0, 255)
        val b = (Color.blue(c) * (1 - t) + 255 * t).toInt().coerceIn(0, 255)
        return Color.rgb(r, g, b)
    }

    private fun isLit(bmp: Bitmap, col: Int, row: Int): Boolean {
        if (col < 0 || col >= bmp.width || row < 0 || row >= bmp.height) return false
        return Color.alpha(bmp.getPixel(col, row)) > 100
    }

    private fun currentTextColor(): Int {
        return if (config.textColor.isCycle || config.ledEffect == LedEffect.COLOR_CYCLE) {
            Color.HSVToColor(floatArrayOf(hue, 1f, 1f))
        } else {
            config.textColor.color
        }
    }

    private fun drawBackground(canvas: Canvas) {
        when (config.background) {
            Background.BLACK, Background.YOUTUBE_DIM -> {
                bgPaint.color = Color.BLACK
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
            }
            Background.DARK_GRAY -> {
                bgPaint.color = Color.rgb(18, 18, 20)
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
            }
            Background.REFLECTIVE -> {
                bgPaint.color = Color.rgb(10, 12, 16)
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
            }
            Background.LED_GRID -> {
                bgPaint.color = Color.BLACK
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
                val step = pitchPx().coerceAtLeast(8f)
                var x = 0f
                while (x < width) { canvas.drawLine(x, 0f, x, height.toFloat(), gridPaint); x += step }
                var y = 0f
                while (y < height) { canvas.drawLine(0f, y, width.toFloat(), y, gridPaint); y += step }
            }
        }
    }

    private fun drawFrame(canvas: Canvas) {
        if (config.frameEffect == FrameEffect.OFF) return
        val t = pitchPx().coerceAtLeast(6f) * 0.5f
        framePaint.style = Paint.Style.STROKE
        framePaint.strokeWidth = t

        val color = when (config.frameEffect) {
            FrameEffect.COLOR_CHANGING -> Color.HSVToColor(floatArrayOf(hue, 1f, 1f))
            FrameEffect.BLINKING -> if (blinkOn) Color.rgb(255, 40, 40) else Color.rgb(40, 40, 40)
            else -> Color.rgb(60, 120, 255)
        }
        framePaint.color = color
        framePaint.clearShadowLayer()

        val inset = t
        if (config.frameEffect == FrameEffect.RUNNING_DOTS) {
            drawRunningDots(canvas, inset, t)
        } else {
            canvas.drawRect(inset, inset, width - inset, height - inset, framePaint)
        }
    }

    private fun drawRunningDots(canvas: Canvas, inset: Float, t: Float) {
        framePaint.style = Paint.Style.FILL
        val gap = t * 2.2f
        val r = t * 0.5f
        val phase = (scrollOffset * 2f) % (gap * 2f)
        var x = inset + phase
        while (x < width - inset) {
            framePaint.color = Color.HSVToColor(floatArrayOf((hue + x) % 360f, 1f, 1f))
            canvas.drawCircle(x, inset, r, framePaint)
            canvas.drawCircle(x, height - inset, r, framePaint)
            x += gap
        }
        var y = inset + phase
        while (y < height - inset) {
            framePaint.color = Color.HSVToColor(floatArrayOf((hue + y) % 360f, 1f, 1f))
            canvas.drawCircle(inset, y, r, framePaint)
            canvas.drawCircle(width - inset, y, r, framePaint)
            y += gap
        }
    }

    // ---- External controls (used by full screen activity / D-pad) ----

    fun increaseSpeed() {
        val values = com.arif.ledtvbanner.data.ScrollSpeed.values()
        val i = values.indexOf(config.speed)
        if (i < values.size - 1) config.speed = values[i + 1]
    }

    fun decreaseSpeed() {
        val values = com.arif.ledtvbanner.data.ScrollSpeed.values()
        val i = values.indexOf(config.speed)
        if (i > 0) config.speed = values[i - 1]
    }

    fun increaseSize() {
        val values = com.arif.ledtvbanner.data.TextSize.values()
        val i = values.indexOf(config.size)
        if (i < values.size - 1) { config.size = values[i + 1]; textBitmap = null }
    }

    fun decreaseSize() {
        val values = com.arif.ledtvbanner.data.TextSize.values()
        val i = values.indexOf(config.size)
        if (i > 0) { config.size = values[i - 1]; textBitmap = null }
    }
}
