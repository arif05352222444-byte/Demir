package com.arif.ledtvbanner

import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.arif.ledtvbanner.banner.LedBannerView
import com.arif.ledtvbanner.data.BannerConfig
import com.arif.ledtvbanner.data.BannerStore
import com.arif.ledtvbanner.data.MusicMode
import com.arif.ledtvbanner.data.SettingsStore
import com.arif.ledtvbanner.media.MusicPlayerManager
import com.arif.ledtvbanner.media.YoutubeIdParser
import com.arif.ledtvbanner.media.YoutubeWebViewManager
import com.arif.ledtvbanner.util.Constants
import com.arif.ledtvbanner.util.SystemUiHelper
import org.json.JSONObject

/**
 * The main attraction: full-screen LED sign.
 * - LED text scrolls on top.
 * - Optional YouTube video / MP3 / radio plays behind it.
 * - Controlled entirely by the TV remote (D-pad).
 */
class FullScreenBannerActivity : AppCompatActivity() {

    private lateinit var banner: LedBannerView
    private lateinit var config: BannerConfig
    private lateinit var music: MusicPlayerManager

    private var webView: WebView? = null
    private var dimView: View? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fullscreen)

        val settings = SettingsStore(this)
        SystemUiHelper.enterImmersive(this, settings.keepScreenOn)

        val json = intent.getStringExtra(Constants.EXTRA_BANNER_JSON)
        config = try {
            if (json != null) BannerConfig.fromJson(JSONObject(json)) else BannerConfig()
        } catch (e: Exception) { BannerConfig() }

        BannerStore(this).setLastUsed(config)

        banner = findViewById(R.id.bannerView)
        banner.config = config.copyOf()
        banner.requestFocus()

        music = MusicPlayerManager(this)
        music.onError = { msg ->
            runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
        }

        setupMedia()
    }

    private fun setupMedia() {
        when (config.musicMode) {
            MusicMode.OFF -> { /* nothing */ }
            MusicMode.LOCAL_MP3 -> {
                if (config.musicUri.isNotBlank()) {
                    music.playUri(config.musicUri, config.loop, config.volume)
                }
            }
            MusicMode.RADIO -> {
                if (config.radioUrl.isNotBlank()) {
                    music.playStream(config.radioUrl, config.loop, config.volume)
                } else {
                    Toast.makeText(this, "Radyo linki boş.", Toast.LENGTH_SHORT).show()
                }
            }
            MusicMode.YOUTUBE -> setupYoutube()
        }
    }

    private fun setupYoutube() {
        val id = YoutubeIdParser.parse(config.youtubeUrl)
        if (id == null) {
            Toast.makeText(this, "Geçersiz YouTube linki. Sadece banner gösterilecek.",
                Toast.LENGTH_LONG).show()
            return
        }
        val root = findViewById<FrameLayout>(R.id.root)
        // WebView goes BEHIND the banner (added at index 0).
        val wv = WebView(this)
        wv.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
        )
        root.addView(wv, 0)
        webView = wv

        // Dim overlay on top of the video but below the banner.
        val dim = View(this)
        dim.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
        )
        val alpha = (config.youtubeDim.coerceIn(0, 75) * 255 / 100)
        dim.setBackgroundColor(android.graphics.Color.argb(alpha, 0, 0, 0))
        root.addView(dim, 1)
        dimView = dim

        YoutubeWebViewManager.load(wv, id) {
            runOnUiThread {
                Toast.makeText(this, "YouTube açılamadı. Sadece banner gösteriliyor.",
                    Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                banner.togglePause()
                if (banner.isPaused()) music.pause() else music.resume()
                return true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> { banner.increaseSpeed(); toast("Hız +"); return true }
            KeyEvent.KEYCODE_DPAD_LEFT -> { banner.decreaseSpeed(); toast("Hız -"); return true }
            KeyEvent.KEYCODE_DPAD_UP -> { banner.increaseSize(); toast("Boyut +"); return true }
            KeyEvent.KEYCODE_DPAD_DOWN -> { banner.decreaseSize(); toast("Boyut -"); return true }
            KeyEvent.KEYCODE_BACK -> { finish(); return true }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    override fun onPause() {
        super.onPause()
        music.pause()
        try { webView?.onPause() } catch (_: Exception) {}
    }

    override fun onResume() {
        super.onResume()
        try { webView?.onResume() } catch (_: Exception) {}
    }

    override fun onDestroy() {
        music.release()
        YoutubeWebViewManager.destroy(webView)
        webView = null
        SystemUiHelper.clearKeepScreenOn(this)
        super.onDestroy()
    }
}
